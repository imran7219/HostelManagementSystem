CREATE DATABASE HostelManagement;
USE HostelManagement;

CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100),
    Department NVARCHAR(50),
    Contact NVARCHAR(15)
);

CREATE TABLE Rooms (
    RoomID INT PRIMARY KEY IDENTITY(1,1),
    RoomNumber NVARCHAR(10),
    Capacity INT,
    Occupied INT DEFAULT 0
);

CREATE TABLE Allocations (
    AllocationID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID),
    RoomID INT FOREIGN KEY REFERENCES Rooms(RoomID),
    AllocationDate DATETIME DEFAULT GETDATE()
);

CREATE TABLE Fees (
    FeeID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID),
    Amount DECIMAL(10,2),
    PaymentDate DATETIME DEFAULT GETDATE()
);
