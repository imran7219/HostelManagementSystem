using System;
using System.Data;
using System.Data.SqlClient;

public class DBHelper
{
    private string connectionString = @"Data Source=YOUR_SERVER_NAME;Initial Catalog=HostelManagement;Integrated Security=True";

    public DataTable GetDataTable(string query)
    {
        using(SqlConnection con = new SqlConnection(connectionString))
        {
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }

    public int ExecuteQuery(string query)
    {
        using(SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            return cmd.ExecuteNonQuery();
        }
    }
}
