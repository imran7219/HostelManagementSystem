# Hostel Management System

A simple C# Windows Forms application to manage students, rooms, allocations, and fees for a hostel.

## Features

- Add, edit, delete student records
- Manage rooms and capacity
- Allocate rooms to students
- Record fee payments

## Tools & Technologies

- C# Windows Forms
- SQL Server (Express or full)
- ADO.NET for database connectivity

## Setup Instructions

1. Create the database using the provided SQL script.
2. Update the connection string in `DBHelper.cs` with your SQL Server instance.
3. Build and run the solution in Visual Studio.
4. Use the forms to manage the hostel data.

## Author

Your Name
